#Function for trace
tr<-function(A){
  return(sum(diag(A)))
}
